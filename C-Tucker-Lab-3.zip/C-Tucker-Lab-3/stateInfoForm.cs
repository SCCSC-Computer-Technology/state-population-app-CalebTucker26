﻿using C_Tucker_Lab_3.USStatesDBDataSetTableAdapters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C_Tucker_Lab_3
{
    public partial class stateInfoForm : Form
    {

        //This initializes the second form, shows the label, and displays the state info.
        public stateInfoForm(StringBuilder sb)
        {
            InitializeComponent();
            lblStateInfo.Visible = true;
            lblStateInfo.Text = sb.ToString();
        }

      
    }
}
