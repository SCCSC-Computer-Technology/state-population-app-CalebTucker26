﻿namespace C_Tucker_Lab_3
{


    partial class USStatesDBDataSet
    {
    }
}
