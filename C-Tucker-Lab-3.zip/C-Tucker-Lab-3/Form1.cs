﻿/*Caleb Tucker
 * Lab-3
 * CPT-206_A80H*/

using C_Tucker_Class_Library;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C_Tucker_Lab_3
{
    public partial class USStatesApplication : Form
    {
        public USStatesApplication()
        {
            InitializeComponent();
        }

        //On loading the form this method creates the table and populates the combo box.
        private void USStatesApplication_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'uSStatesDBDataSet.States' table. You can move, or remove it, as needed.
            this.statesTableAdapter.Fill(this.uSStatesDBDataSet.States);

            comboBoxStates.Items.Clear();
            PopulateStatesComboBox();
            
        }

    

        //This method populates the combo box with all 50 states.
        private void PopulateStatesComboBox()
        {
            foreach(var row in this.uSStatesDBDataSet.States)
            {
                comboBoxStates.Items.Add(row.StateName);
            }
        }

        //This Method creates a state object and populates it with the correct data using a query that searches for the specific record in the table.
        public State GetStateObject()
        {

            try
            {
                string selectState = comboBoxStates.SelectedItem.ToString();

                {
                    var table = statesTableAdapter.GetDataBySpecificState(selectState);
                    if (table.Rows.Count == 0)
                        return null;
                    var row = table[0];
                    State state = new State()
                    {
                        StateName = row.StateName,
                        Population = row.Population,
                        MedianIncome = row.MedianIncome,
                        ComputerJobsPercent = row.ComputerJobsPercent,
                        StateFlagDescription = row.StateFlagDescription,
                        StateFlower = row.StateFlower,
                        StateBird = row.StateBird,
                        Colors = row.Colors,
                        LargestCity1 = row.LargestCity1,
                        LargestCity2 = row.LargestCity2,
                        LargestCity3 = row.LargestCity3,
                        StateCapitol = row.StateCapitol,
                    };
                    return state;
                }
            }
            catch
            {
                MessageBox.Show("There was an error retrieving the data please try again.");
                return null;
            }
        }

        //This method creates a string builder and appends it to create a string with all of the data of the selected state.
        private StringBuilder StateInfoSB()
        {
            
            State state = GetStateObject();
            StringBuilder sb = new StringBuilder();
            if (state != null)
            {
                sb.AppendLine($"State Name: {state.StateName}");
                sb.AppendLine($"Population: {state.Population:N0}");
                sb.AppendLine($"Median Income: ${state.MedianIncome:N2}");
                sb.AppendLine($"Computer Jobs Percent: {state.ComputerJobsPercent}%");
                sb.AppendLine($"State Flag Description: {state.StateFlagDescription}");
                sb.AppendLine($"State Flower: {state.StateFlower}");
                sb.AppendLine($"State Bird: {state.StateBird}");
                sb.AppendLine($"Colors: {state.Colors}");
                sb.AppendLine($"Largest Cities: {state.LargestCity1}, {state.LargestCity2}, {state.LargestCity3}");
                sb.AppendLine($"State Capitol: {state.StateCapitol}");
            }
            return sb;
        }

        //Opens a new form that displays the selected state information.
        private void btnStateInfo_Click(object sender, EventArgs e)
        {
            State state = GetStateObject();
            if (state != null)
            {
                Form form2 = new stateInfoForm(StateInfoSB());
                form2.Show();
            }
        }

        //Closes the Form.
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //This method allows you to search by State
        private void btnStateInfoTable_Click(object sender, EventArgs e)
        {
            try
            {
                string selectState = comboBoxStates.SelectedItem.ToString();
                this.statesTableAdapter.FillBySpecificState(uSStatesDBDataSet.States, selectState);
            }
            catch
            {
                MessageBox.Show("Please select a state from the drop down menu.");
            }
        }

        //This method runs the sort queries to sort the database.
        private void SortQuerySelection()
        {
            if (comboBoxSort.SelectedIndex>= 0 && comboBoxSort.SelectedIndex<=23)
            {
                switch (comboBoxSort.SelectedIndex)
                {

                    case 0:
                        this.statesTableAdapter.FillBySortStateNameASC(uSStatesDBDataSet.States);
                        break;
                    case 1:
                        this.statesTableAdapter.FillBySortStateNameDESC(uSStatesDBDataSet.States);
                        break;
                    case 2:
                        this.statesTableAdapter.FillBySortByPopulationASC(uSStatesDBDataSet.States);
                        break;
                    case 3:
                        this.statesTableAdapter.FillBySortByPopulationDESC(uSStatesDBDataSet.States);
                        break;
                    case 4:
                        this.statesTableAdapter.FillBySortMedianIncomeASC(uSStatesDBDataSet.States);
                        break;
                    case 5:
                        this.statesTableAdapter.FillBySortMedianIncomeDESC(uSStatesDBDataSet.States);
                        break;
                    case 6:
                        this.statesTableAdapter.FillBySortStateFlagASC(uSStatesDBDataSet.States);
                        break;
                    case 7:
                        this.statesTableAdapter.FillBySortStateFlagDESC(uSStatesDBDataSet.States);
                        break;
                    case 8:
                        this.statesTableAdapter.FillBySortStateFlowerASC(uSStatesDBDataSet.States);
                        break;
                    case 9:
                        this.statesTableAdapter.FillBySortByStateFlowerDESC(uSStatesDBDataSet.States);
                        break;
                    case 10:
                        this.statesTableAdapter.FillBySortStateBirdASC(uSStatesDBDataSet.States);
                        break;
                    case 11:
                        this.statesTableAdapter.FillBySortStateBirdDESC(uSStatesDBDataSet.States);
                        break;
                    case 12:
                        this.statesTableAdapter.FillBySortColorsASC(uSStatesDBDataSet.States);
                        break;
                    case 13:
                        this.statesTableAdapter.FillBySortColorsDESC(uSStatesDBDataSet.States);
                        break;
                    case 14:
                        this.statesTableAdapter.FillBySortLargestCity1ASC(uSStatesDBDataSet.States);
                        break;
                    case 15:
                        this.statesTableAdapter.FillBySortLargestCity1DESC(uSStatesDBDataSet.States);
                        break;
                    case 16:
                        this.statesTableAdapter.FillBySortLargestCity2ASC(uSStatesDBDataSet.States);
                        break;
                    case 17:
                        this.statesTableAdapter.FillBySortLargestCity2DESC(uSStatesDBDataSet.States);
                        break;
                    case 18:
                        this.statesTableAdapter.FillBySortLargestCity3ASC(uSStatesDBDataSet.States);
                        break;
                    case 19:
                        this.statesTableAdapter.FillBySortLargestCity3DESC(uSStatesDBDataSet.States);
                        break;
                    case 20:
                        this.statesTableAdapter.FillBySortStateCapitolASC(uSStatesDBDataSet.States);
                        break;
                    case 21:
                        this.statesTableAdapter.FillBySortStateCapitolDESC(uSStatesDBDataSet.States);
                        break;
                    case 22:
                        this.statesTableAdapter.FillBySortComputerJobsASC(uSStatesDBDataSet.States);
                        break;
                    case 23:
                        this.statesTableAdapter.FillBySortComputerJobsDESC(uSStatesDBDataSet.States);
                        break;
                }
            }
            else
            {
                MessageBox.Show("Please select a sorting method from the drop down menu.");
            }
        }

        //This method takes the user input and searches the database.
        private void UserSearch()
        {
            int medianIncome = 0;
            long population = 0;
            decimal jobPercentage = 0;
            string userInput = "";
            try
            {
                if (comboBoxSearch.SelectedIndex>=0 && comboBoxSearch.SelectedIndex <= 10)
                {
                    switch (comboBoxSearch.SelectedIndex)
                    {
                        case 0:
                            if (long.TryParse(txtBoxUserSearch.Text, out population))
                                {
                                this.statesTableAdapter.FillBySearchByPopulation(uSStatesDBDataSet.States, population);
                            }
                            else
                            {
                                MessageBox.Show("Please enter a valid number for population.");
                            }
                                break;
                        case 1:
                            if (int.TryParse(txtBoxUserSearch.Text, out medianIncome))
                            {
                                this.statesTableAdapter.FillBySearchByMedianIncom(uSStatesDBDataSet.States, medianIncome);
                            }
                            else
                            {
                                MessageBox.Show("Please enter a valid number for Median Income.");
                            }
                                break;
                        case 2:
                            userInput = txtBoxUserSearch.Text;
                            this.statesTableAdapter.FillBySearchStateFlagDescription(uSStatesDBDataSet.States, userInput);
                            break;
                        case 3:
                            userInput = txtBoxUserSearch.Text;
                            this.statesTableAdapter.FillBySearchStateFlower(uSStatesDBDataSet.States, userInput);
                            break;
                        case 4:
                            userInput = txtBoxUserSearch.Text;
                            this.statesTableAdapter.FillBySearchStateBird(uSStatesDBDataSet.States, userInput);
                            break;
                        case 5:
                            userInput = txtBoxUserSearch.Text;
                            this.statesTableAdapter.FillBySearchColors(uSStatesDBDataSet.States, userInput);
                            break;
                        case 6:
                            userInput = txtBoxUserSearch.Text;
                            this.statesTableAdapter.FillBySearchLargestCity1(uSStatesDBDataSet.States, userInput);
                            break;
                        case 7:
                            userInput = txtBoxUserSearch.Text;
                            this.statesTableAdapter.FillBySearchLargestCity2(uSStatesDBDataSet.States, userInput);
                            break;
                        case 8:
                            userInput = txtBoxUserSearch.Text;
                            this.statesTableAdapter.FillBySearchLargestCity3(uSStatesDBDataSet.States, userInput);
                            break;
                        case 9:
                            userInput = txtBoxUserSearch.Text;
                            this.statesTableAdapter.FillBySearchByStateCapitol(uSStatesDBDataSet.States, userInput);
                            break;
                        case 10:
                            if (decimal.TryParse(txtBoxUserSearch.Text, out jobPercentage))
                            {
                                this.statesTableAdapter.FillBySearchComputerJobsPercent(uSStatesDBDataSet.States, jobPercentage);
                            }
                            else
                            {
                                MessageBox.Show("Please enter a valid decimal for the Computer Jobs Percentage.");
                            }
                                break;
                    }
                }
                else
                {
                    MessageBox.Show("Please select the column your trying to search by from the drop down menu.");
                }
            }
            catch
            {
                MessageBox.Show("Nothing matches your search. Please try again.");
            }
        }

        //This method runs the sort method and displays the results
        private void btnSort_Click(object sender, EventArgs e)
        {
            SortQuerySelection();
        }

        //This method runs the search method and displays the results.
        private void btnSearch_Click(object sender, EventArgs e)
        {
            UserSearch();
        }

        //This Method clears/resets the form.
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtBoxUserSearch.Clear();
            comboBoxSearch.SelectedIndex = -1;
            comboBoxSort.SelectedIndex = -1;
            comboBoxStates.SelectedIndex = -1;
            this.statesTableAdapter.Fill(this.uSStatesDBDataSet.States);
        }

        private void statesBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.statesBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.uSStatesDBDataSet);

        }
    }
}
